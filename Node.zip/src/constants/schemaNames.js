/**
 * DataBase Schema Name
 */
export const SCHEMA_NAMES = {
	USER: "USER",
	PRODUCT: "PRODUCT",
};
